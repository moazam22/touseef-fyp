from django.shortcuts import render,redirect
from .forms import loginform,signupform
from admins.models import Admins 
from django.contrib import messages


# def image_view(request): 
  
#     if request.method == 'POST': 
#         form = ImgForm(request.POST, request.FILES) 
  
#         if form.is_valid(): 
#             form.save() 
#             return redirect('success') 
#     else: 
#         form = ImgForm() 
#     return render(request, 'images.html', {'form' : form}) 
  
  
# def success(request): 
#     return HttpResponse('successfully uploaded')






def loginpage(request):
	try:
		cadmin=Admins()
		cadmin=Admins.objects.get(flag=1)
		if cadmin is not None:
			cadmin.flag=0
			cadmin.save()
			logform=loginform()
			context1={
			"title":"login Page",
			"form":logform,
			}
			return render(request,"login.html",context1)
	except:
		logform=loginform(request.POST or None)
		if request.method == 'POST':
			if logform.is_valid():
				users=Admins.objects.all()
				flag=0
				for x in users:
					if logform.cleaned_data['Username']==x.username:
						if logform.cleaned_data['Password']==x.password:
							if x.flag == 0:
								flag=1
								print('User logged in Successfully.')
								context={
								"title":"Home Page",
								'admin_id':x.admin_id, 
								'first_name':x.first_name, 
								'last_name':x.last_name,
								'username':x.username,
								'password':x.password,
								'email':x.email,
								'phone_no' : x.phone_no
								} 
								context1=context
								cadmin=Admins()
								cadmin=Admins.objects.get(admin_id=x.admin_id)
								cadmin.flag=1
								cadmin.save()
								#print(context1['title'])
								return render(request, "home_page.html",context)
								break
							else:
								messages.info(request,'user already logged in')
								print('user already logged in')

				if flag == 0:
					messages.info(request,'Invalid Username or Password.')
					print('Invalid Username or Password.')
			else:
				print("Form invalid")
		else:
			#print("Get")
			logform=loginform()
		context1={
		"title":"login Page",
		"form":logform,
		}
	return render(request,"login.html",context1)

def signup(request):
	if request.method=="POST":
		form=signupform(request.POST)
		if form.is_valid():
			try:
				users=Admins.objects.all()
				flagg=0
				for user in users:
					#print('in loop')
					if form.cleaned_data['Email']==user.email:
						if form.cleaned_data['Username']==user.username:
							# print('Clear')
							flagg=1
				if flagg==0:
					#print('saving')
					cadmin=Admins()
					cadmin.first_name=form.cleaned_data['First_Name']
					cadmin.last_name=form.cleaned_data['Last_Name']
					cadmin.username=form.cleaned_data['Username']
					cadmin.password=form.cleaned_data['Password']
					cadmin.email=form.cleaned_data['Email']
					cadmin.phone_no=form.cleaned_data['Phone_Number']
					cadmin.flag=0
					cadmin.save()
					# form.save()
					context1={
					"title":"login Page",
					"form":loginform,
					}
					return redirect('login')
					# return render(request,"login.html",context1)
				else:
					messages.info(request, "user already exist! try new username and email.")
					print("user already exist! try new username and email.")
			except:
				pass
		else:
			messages.info(request,'Form Validation erorr')
			print("Form Validation erorr")
	else:
		form=signupform()
	return render(request,"signup.html",{"form":form})