from django import forms
from django.utils.safestring import mark_safe
from admins.models import Admins
import re





class loginform(forms.Form):
	Username=forms.CharField(
		widget=forms.TextInput(
			attrs={
				"class":"form-control",
				"placeholder":"Username"
			}
			)
		)
	Password=forms.CharField(label=mark_safe("</br>Password"),
		widget=forms.PasswordInput(
			attrs={
				"class":"form-control",
				"placeholder":"Password"
			}
			)
		)
	def clean_Username(self):
		username=self.cleaned_data.get("Username")
		return username

# class signupform(forms.ModelForm):
# 	password = forms.CharField(widget=forms.PasswordInput)
# 	class Meta:
# 		model=Admins
# 		fields=['first_name','last_name','username','password','email','phone_no','flag']
# 	def clean_name(self):
# 		Name=self.cleaned_data.get("first_name")
# 		return Name

# 	def clean_uname(self):
# 		uName=self.cleaned_data.get("username")
# 		return uName

# 	def clean_passwword(self):
# 		passw=self.cleaned_data.get("password")
# 		return passw


class signupform(forms.Form):
	First_Name=forms.CharField(
		widget=forms.TextInput(
			attrs={
				"class":"form-control",
				"placeholder":"first_name"
			}
			)
		)

	Last_Name=forms.CharField(
		widget=forms.TextInput(
			attrs={
				"class":"form-control",
				"placeholder":"last_name"
			}
			)
		)

	Username=forms.CharField(
		widget=forms.TextInput(
			attrs={
				"class":"form-control",
				"placeholder":"Username"
			}
			)
		)



	Password=forms.CharField(label=mark_safe("</br>Password"),
		widget=forms.PasswordInput(
			attrs={
				"class":"form-control",
				"placeholder":"Password"
			}
			)
		)

	Email=forms.CharField(
		widget=forms.TextInput(
			attrs={
				"class":"form-control",
				"placeholder":"email"
			}
			)
		)

	Phone_Number=forms.CharField(
		widget=forms.TextInput(
			attrs={
				"class":"form-control",
				"placeholder":"phone_no"
			}
			)
		)

	def clean_First_Name(self):
		fname=self.cleaned_data.get("First_Name")
		return fname

	def clean_last_Name(self):
		lname=self.cleaned_data.get("last_Name")
		return lname






	def clean_Username(self):
		username=self.cleaned_data.get("Username")
		return username


	def clean_Password(self):
		passw=self.cleaned_data.get("Password")
		return passw



	def clean_Email(self):
		email=self.cleaned_data.get("Email")
		return email

	def clean_Phone_Number(self):
		pno=self.cleaned_data.get("Phone_Number")
		return pno

